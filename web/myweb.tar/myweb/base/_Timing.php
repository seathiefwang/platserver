<?php


require_once (__DIR__."/../libs/Error.php");
/**
 * 托管类
 * @author 律鑫
 * @version 1.0
 * @created 09-六月-2015 11:20:02
 */
class _Timing
{

	public $m_Error;

	public function __construct()
	{
	}

	public function __destruct()
	{
	}

	/**
	 * 
	 * @param params    params
	 */
	public static function _Create($params)
	{
	}

	/**
	 * 
	 * @param params    params
	 */
	public static function _Destroy($params)
	{
	}

	/**
	 * 获得托管模式列表
	 * 
	 * @param params    params
	 */
	public static function _List($params)
	{
	}

	/**
	 * 获得模式信息
	 * 
	 * @param params    params
	 */
	public static function _GetInfo($params)
	{
	}

	/**
	 * 修改模式信息
	 * 
	 * @param params    params
	 */
	public static function _Modify($params)
	{
	}

	/**
	 * 使能托管模式
	 * 
	 * @param params    params
	 */
	public static function _Enable($params)
	{
	}

}
?>