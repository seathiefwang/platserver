<?php


require_once (__DIR__."/../libs/DeviceControl.php");
/**
 * @author 律鑫
 * @version 1.0
 * @created 09-六月-2015 11:20:02
 */
class _Switch extends DeviceControl
{

	public function __construct()
	{
	}

	public function __destruct()
	{
	}

	/**
	 * 开灯
	 * 
	 * @param params    params
	 */
	public static function _TurnOn($params)
	{
	}

	/**
	 * 关灯
	 * 
	 * @param params    params
	 */
	public static function _TurnOff($params)
	{
	}

	/**
	 * 状态翻转
	 * 
	 * @param params    params
	 */
	public static function _TurnTog($params)
	{
	}

	/**
	 * 全开
	 * 
	 * @param params    params
	 */
	public static function _AllOn($params)
	{
	}

	/**
	 * 全关
	 * 
	 * @param params    params
	 */
	public static function _AllOff($params)
	{
	}

	/**
	 * 查询状态
	 * 
	 * @param params    params
	 */
	public static function _Query($params)
	{
	}

}
?>